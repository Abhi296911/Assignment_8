import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>Welcome to the AI Chat Application</h1>
            <p>This application uses AI to enhance your conversations.</p>
        </div>
    );
};

export default Home;

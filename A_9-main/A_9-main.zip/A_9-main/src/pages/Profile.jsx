import React from 'react';

const Profile = () => {
    return (
        <div>
            <h1>User Profile</h1>
            <p>Details about the user will be displayed here.</p>
        </div>
    );
};

export default Profile;
